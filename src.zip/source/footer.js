import React, {Component} from 'react';
import './ect.css'



class Footer extends Component{
    render(){
        return(
            <div className="footer">Footer</div>
        );
    }
}
export default Footer;