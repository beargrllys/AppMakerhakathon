import React, {Component} from 'react';
import './table.css'



class Submit extends Component{
    render(){
        return(
            <div className="tableBox">
                <div className="columnBox">
                    <div className="tableTitle">
                        <p>#과제 제출하기</p>
                    </div>
                    <div className="">
                        <table className="table table-striped">
                            <thead>
                                <tr>
                                    <th>제출과제</th>
                                    <th>제출하기</th>
                                    <th>제출날짜</th>
                                    <th>제출여부</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1차 멘토링 결과보고서</td>
                                    <td>
                                        <input type="file" name="file" onChange={null}/>
                                    </td>
                                    <td>8-27</td>
                                    <td>YES</td>
                                </tr>
                                <tr>
                                    <td>2차 멘토링 결과보고서</td>
                                    <td>
                                        <input type="file" name="file" onChange={null}/>
                                    </td>
                                    <td>8-28</td>
                                    <td>YES</td>
                                </tr>
                                <tr>
                                    <td>3차 멘토링 결과보고서</td>
                                    <td>
                                        <input type="file" name="file" onChange={null}/>
                                    </td>
                                    <td>8-29</td>
                                    <td>NO</td>
                                </tr>
                                <tr>
                                    <td>4차 멘토링 결과보고서</td>
                                    <td>
                                        <input type="file" name="file" onChange={null}/>
                                    </td>
                                    <td>8-30</td>
                                    <td>NO</td>
                                </tr>
                                <tr>
                                    <td>최종 결과물 제출</td>
                                    <td>
                                        <input type="file" name="file" onChange={null}/>
                                    </td>
                                    <td>8-31</td>
                                    <td>NO</td>
                                </tr>
                            </tbody>
                        </table>

                        <div className="text-center">
                            <ul className="pagination">
                                <li className="page-item"><a className="page-link" href="/">Previous</a></li>
                                <li className="page-item"><a className="page-link" href="/">1</a></li>
                                <li className="page-item"><a className="page-link" href="/">2</a></li>
                                <li className="page-item"><a className="page-link" href="/">3</a></li>
                                <li className="page-item"><a className="page-link" href="/">Next</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Submit;