import React, {Component} from 'react';
import logo from './image/LOGO.png';


class MenuBar extends Component{
    render(){
        return(
        <div className="side">
          <nav>
            <a className="logo" href="/ ">
              <img src={logo} alt="logo_pic" className="image_size"/>
            </a>
            <div className="label logosen text_center menu_icon"> OHS Flatform</div>
            <div className="scrollbar text_center menu_icon" onClick={function(e){
              e.preventDefault();
              this.props.onChangeMain('default');
              this.props.onChangeSide('default');
            }.bind(this)}>
              <a href=" "className="text_center">
                  <span className="fa">HOME</span>
              </a>
            </div>
            <div className="scrollbar text_center menu_icon" onClick={function(e){
              e.preventDefault();
              this.props.onChangeSide('friend');
            }.bind(this)}>
              <a href=" "className="text_center">
                  <span className="fa">친구창</span>
              </a>
            </div>
            <div className="scrollbar text_center menu_icon" onClick={function(e){
              e.preventDefault();
              this.props.onChangeSide('portfolio');
            }.bind(this)}>
              <a href=" "className="text_center">
                  <span className="fa">포트폴리오</span>
              </a>
            </div>
            <div className="label logosen text_center menu_icon"> 대회 정보</div>
            <div className="scrollbar text_center menu_icon" onClick={function(e){
              e.preventDefault();
              this.props.onChangeMain('notice');
            }.bind(this)}>
              <a href=" "className="text_center">
                  <span className="fa">대회 공지사항</span>
              </a>
            </div>
            <div className="scrollbar text_center menu_icon" onClick={function(e){
              e.preventDefault();
              this.props.onChangeMain('submit');
            }.bind(this)}>
              <a href=" "className="text_center">
                  <span className="fa">대회 제출자료</span>
              </a>
            </div>
            <div className="scrollbar text_center menu_icon" onClick={function(e){
              e.preventDefault();
              this.props.onChangeSide('friend');
            }.bind(this)}>
              <a href=" "className="text_center">
                  <span className="fa">팀채팅</span>
              </a>
            </div>
            <div className="label logosen text_center menu_icon"> 관리자 메뉴</div>
            <div className="scrollbar text_center menu_icon" onClick={function(e){
              e.preventDefault();
              this.props.onChangeMain('admin');
            }.bind(this)}>
              <a href=" "className="text_center">
                  <span className="fa">관리자 페이지 보기</span>
              </a>
            </div>
            <div className="scrollbar text_center menu_icon" onClick={function(e){
              e.preventDefault();
              this.props.onChangeMain('newContest');
            }.bind(this)}>
              <a href=" "className="text_center">
                  <span className="fa">새로운 해커톤 시작하기</span>
              </a>
            </div>
            <div className="scrollbar text_center menu_icon" onClick={function(e){
              e.preventDefault();
              this.props.onChangeMain('announce');
            }.bind(this)}>
              <a href=" "className="text_center">
                  <span className="fa">참가자에게 공지하기</span>
              </a>
            </div>
        </nav>
        </div>
        );
    }
}

export default MenuBar;