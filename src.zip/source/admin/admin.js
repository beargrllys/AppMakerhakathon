import React, {Component} from 'react';
import './admin.css'



class Admin extends Component{
    render(){
        return(
            <div>Footer</div>
        );
    }
}
export default Admin;