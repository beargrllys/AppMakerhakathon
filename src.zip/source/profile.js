import React, {Component} from 'react';
import './Rside.css'
import profileImages from './image/profileImage.png'
import abjustIcon from './image/adjust.png';


class Profile extends Component{
    render(){
        return(
          <div className="sideCase">
            <div className="sideTitle"><p>포트폴리오</p></div>
            <div className="profileImageBox">
              <img src={profileImages} alt="profileImage" className="profileImage"></img>
            </div>
            <div className="profileName fontLarge">
              <p>홍길동
              <button className="editButton"><img src={abjustIcon} alt="edit" className="editButton"></img></button>
              </p>
            </div>
            <div className="profileContent">
              <p className="fontMiddle">소속: 한양대학교 ICT융합학부</p>
              <p className="fontMiddle">지역: 경기도 안산시</p>
            </div>
            <div className="profileContent">
              <p className="fontLarge">#능력
              <button className="editButton"><img src={abjustIcon} alt="edit" className="editButton"></img></button>
              </p>
              <p className="fontMiddle">기획 경험 다수</p>
              <p className="fontMiddle">Adobe XD 사용가능</p>
              <p className="fontMiddle">MOS Word expert</p>
            </div>
            <div className="profileContent">
              <p className="fontLarge">#참가경력
              <button className="editButton"><img src={abjustIcon} alt="edit" className="editButton"></img></button>
              </p>
              <p className="fontMiddle">아이디어톤 1회 참가</p>
              <p className="fontMiddle">아이디어톤 2회 참가</p>
            </div>
          </div>
        );
    }
}

export default Profile;