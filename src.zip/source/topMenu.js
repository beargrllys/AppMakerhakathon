import React, { Component } from 'react';
import './Rside.css'
import { Dropdown } from 'react-bootstrap';
import profileImages from './image/profileImage.png'



class TopMenu extends Component {
    render() {
        return (
            <div className="divLeft">
                <div className="btn-group contestDropdownCustom">
                    <Dropdown>
                        <Dropdown.Toggle variant="scondary" id="dropdown-basic" className="fillDropdown">
                            대회 선택하기
                </Dropdown.Toggle>

                        <Dropdown.Menu>
                            <Dropdown.Item href="#/action-1" style={{ width: 500 }}>제2회 창업아이디어톤</Dropdown.Item>
                            <Dropdown.Item href="#/action-2" style={{ width: 500 }}>제3회 아이디어톤</Dropdown.Item>
                            <Dropdown.Item href="#/action-3" style={{ width: 500 }}>제1회 코딩 마라톤</Dropdown.Item>
                        </Dropdown.Menu>
                    </Dropdown>
                </div>
                <div className="btn-group loginMargin">
                    <div className="loginImageBox">
                        <img src={profileImages} alt="profileImage" className="loginImage"></img>
                    </div>
                    <Dropdown>
                        <Dropdown.Toggle variant="scondary" id="dropdown-basic">
                            로그인
                </Dropdown.Toggle>

                        <Dropdown.Menu>
                            <Dropdown.Item href="#/action-1" onClick={function (e) {
                                e.preventDefault();
                                this.props.onChangeSide('Login');
                            }.bind(this)}>로그인</Dropdown.Item>
                            <Dropdown.Item href="#/action-2" onClick={function (e) {
                                e.preventDefault();
                                this.props.onChangeMain('Signup');
                            }.bind(this)}>회원가입</Dropdown.Item>
                            <Dropdown.Item href="#/action-3" onClick={function (e) {
                                e.preventDefault();
                                this.props.onChangeSideMode('default');
                            }.bind(this)}>설명보기</Dropdown.Item>
                        </Dropdown.Menu>
                    </Dropdown>
                </div>
            </div>
        );
    }
}
export default TopMenu;