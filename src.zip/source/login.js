import React, { Component } from 'react';
import './Rside.css'
import { Dropdown } from 'react-bootstrap';
import profileImages from './image/profileImage.png'


class Login extends Component {
    render() {
        return (
            <div className="btn-group loginMargin">
                <div className="loginImageBox">
                    <img src={profileImages} alt="profileImage" className="loginImage"></img>
                </div>
                <Dropdown>
                    <Dropdown.Toggle variant="scondary" id="dropdown-basic">
                        로그인
                    </Dropdown.Toggle>

                    <Dropdown.Menu>
                        <Dropdown.Item href="#/action-1" onClick={function (e) {
                            e.preventDefault();
                            this.props.onChangeSideMode('Login');
                        }.bind(this)}>로그인</Dropdown.Item>
                        <Dropdown.Item href="#/action-2" onClick={function (e) {
                            e.preventDefault();
                            this.props.onChangeMode('Signup');
                        }.bind(this)}>회원가입</Dropdown.Item>
                        <Dropdown.Item href="#/action-3" onClick={function (e) {
                            e.preventDefault();
                            this.props.onChangeSideMode('default');
                        }.bind(this)}>설명보기</Dropdown.Item>
                    </Dropdown.Menu>
                </Dropdown>
            </div>
        );
    }
}
export default Login;