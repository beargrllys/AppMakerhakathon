import React, { Component } from 'react';
import './ect.css'
import { Form, Button } from 'react-bootstrap';


class Signup extends Component {
    render() {
        return (
            <div>
                <div className="sideTitle"><p>회원가입</p></div>
                <Form className="formBox">
                    <Form.Group controlId="formBasicEmail">
                        <Form.Label>이름</Form.Label>
                        <Form.Control type="name" placeholder="Name" />
                        <Form.Text className="text-muted">
                            We'll never share your email with anyone else.
                    </Form.Text>
                    </Form.Group>
                    <Form.Group controlId="formBasicEmail">
                        <Form.Label>이메일</Form.Label>
                        <Form.Control type="email" placeholder="Enter email" />
                        <Form.Text className="text-muted">
                            We'll never share your email with anyone else.
                    </Form.Text>
                    </Form.Group>

                    <Form.Group controlId="formBasicPassword">
                        <Form.Label>비밀번호</Form.Label>
                        <Form.Control type="password" placeholder="Password" />
                    </Form.Group>
                    <Form.Group controlId="exampleForm.ControlSelect1">
                        <Form.Label>Example select</Form.Label>
                        <Form.Control as="select">
                            <option>개발자</option>
                            <option>디자이너</option>
                            <option>기획자</option>
                        </Form.Control>
                    </Form.Group>
                    <Form.Group controlId="exampleForm.ControlTextarea1">
                        <Form.Label>간단한 자기소개</Form.Label>
                        <Form.Control as="textarea" rows="3" />
                    </Form.Group>
                    <Button variant="dark" type="submit">
                        Submit
                    </Button>
                </Form>
            </div>
        );
    }
}
export default Signup;