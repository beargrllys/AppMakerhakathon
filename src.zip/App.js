import React, { Component } from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import MenuBar from './source/menuBar';
import TopMenu from './source/topMenu';
import TodoList from './source/TodoList';
import Profile from './source/profile';
import Chatting from './source/chatting';
import FooterBlock from './source/footer';
import Notice from './source/notice';
import Submit from './source/submit';
import Login from './source/loginform';
import Signup from './source/signup';
import Admin from './source/admin/admin';
import Announ from './source/admin/announce';
import Newcontest from './source/admin/newContest';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      mode: 'default',
      sidemode: 'default',
      contests: [
        { id: 1, title: 'A Hakathon', Url: './source/image/A_hakathon.png' },
        { id: 2, title: 'B Hakathon', Url: './source/image/B_hakathon.png' },
        { id: 3, title: 'C Hakathon', Url: './source/image/C_hakathon.png' },
        { id: 4, title: 'D Hakathon', Url: './source/image/D_hakathon.png' },
        { id: 5, title: 'E Hakathon', Url: './source/image/E_hakathon.png' },
      ]
    }
  }
  getmianContent() {
    {/**/ }
    var content = null;
    if (this.state.mode === 'default') {
      content = <TodoList></TodoList>;
    }
    else if (this.state.mode === 'notice') {
      content = <Notice></Notice>;
    }
    else if (this.state.mode === 'submit') {
      content = <Submit></Submit>;
    }
    else if (this.state.mode === 'admin') {
      content = <Admin></Admin>;
    }
    else if (this.state.mode === 'announce') {
      content = <Announ></Announ>;
    }
    else if (this.state.mode === 'newContest') {
      content = <Newcontest></Newcontest>;
    }
    else if (this.state.mode === 'Signup') {
      content = <Signup></Signup>;
    }
    return content;
  }
  getsideContent() {
    var content = null;
    if (this.state.sidemode === 'default') {
      content = <Profile></Profile>;
    }
    else if (this.state.sidemode === 'friend') {
      content = <Chatting></Chatting>;
    }
    else if (this.state.sidemode === 'portfolio') {
      content = <Profile></Profile>;
    }
    else if (this.state.sidemode === 'Login') {
      content = <Login></Login>;
    }
    return content;
  }
  render() {
    return (
      <div className="containers">
        <div className="topMenu">
          <TopMenu onChangeMain={function (_mode) {
            this.setState({
              mode: _mode
            })
          }.bind(this)}
            onChangeSide={function (_mode) {
              this.setState({
                sidemode: _mode
              })
            }.bind(this)}></TopMenu>
        </div>
        <MenuBar onChangeMain={function (_mode) {
          this.setState({
            mode: _mode
          })
        }.bind(this)}
          onChangeSide={function (_mode) {
            this.setState({
              sidemode: _mode
            })
          }.bind(this)}> </MenuBar>
        <div className="rside">
          {this.getsideContent()}
        </div>
        <div className="main">
          {this.getmianContent()}
        </div>
        <FooterBlock></FooterBlock>
      </div>
    );
  }
}

export default App;
